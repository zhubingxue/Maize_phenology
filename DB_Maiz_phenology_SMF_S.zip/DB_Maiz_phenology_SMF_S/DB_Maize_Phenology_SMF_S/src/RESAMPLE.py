from osgeo import gdal

# 输入文件路径（10米分辨率的作物分类覆盖图）
input_path = "C:\\Users\\Administrator\\Desktop\\SMF_S_Release-main\\SMF_S_Release-main\\data\\JLROI2.tif"

# 输出文件路径（重采样后的500米分辨率的作物分类覆盖图）
output_path = "SMF_S_Release-main/data/cover_image_resampled_500m.tif"

# 打开输入文件
input_dataset = gdal.Open(input_path)

# 获取输入文件的地理转换信息
geotransform = input_dataset.GetGeoTransform()

# 设置输出文件的分辨率为500米
target_resolution = 500
x_res = target_resolution
y_res = -target_resolution  # 负值表示垂直方向

# 设置输出文件的大小（宽度和高度）
width = int(input_dataset.RasterXSize * (geotransform[1] / x_res))
height = int(input_dataset.RasterYSize * (geotransform[5] / abs(y_res)))

# 使用 gdal.Warp 进行重新采样
gdal.Warp(output_path, input_dataset, xRes=x_res, yRes=y_res, width=width, height=height, resampleAlg="near")

# 关闭数据集
input_dataset = None
