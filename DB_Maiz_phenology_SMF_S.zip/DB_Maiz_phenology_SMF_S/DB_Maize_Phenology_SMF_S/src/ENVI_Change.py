import os
from osgeo import gdal

# 设置工作目录
os.chdir(r"C:\Users\Administrator\Desktop\SMF_S_Compare\SMF_S_Release-main\data")

# 打开 TIFF 文件
dataset = gdal.Open("BCROI.tif")

# 获取地理坐标信息
proj, geot = dataset.GetProjection(), dataset.GetGeoTransform()

# 获取玉米分类图像数组
img_cover = dataset.ReadAsArray(0, 0, dataset.RasterXSize, dataset.RasterYSize)

# 创建 ENVI 文件
envi_driver = gdal.GetDriverByName('ENVI')
envi_dataset = envi_driver.Create("BCROI.envi", img_cover.shape[1], img_cover.shape[0], 1, gdal.GDT_Byte)

# 设置地理坐标信息
envi_dataset.SetProjection(proj)
envi_dataset.SetGeoTransform(geot)

# 将玉米分类图像写入 ENVI 文件
envi_dataset.GetRasterBand(1).WriteArray(img_cover)

# 设置 ENVI 文件的显示范围
envi_dataset.GetRasterBand(1).SetNoDataValue(0)  # 设置无效值

# 关闭数据集
envi_dataset = None
dataset = None

