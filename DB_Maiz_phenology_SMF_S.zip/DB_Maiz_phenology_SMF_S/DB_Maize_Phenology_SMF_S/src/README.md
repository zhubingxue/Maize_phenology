This project demonstrates the application of Adaptive Shape Model (ASM) fitting for determining corn phenological stages in Jilin Province, with Baicheng City serving as a case study. The following section elucidates the functional definitions of each file within the src directory:
chensg: A simplified Chen SG Filter implement.
smf_s_class: SMFS method core code. 
ENVI_Change：tif to ENVI
RESAMPLE：Crop cover resampling
There is a full demonstration of using SMFS in "example/MOD09A1/BCNDVI.ipynb.