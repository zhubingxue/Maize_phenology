import os
import subprocess

# 定义文件夹路径和起始、结束年份
folder_path = '日均温'  # 替换为实际的文件夹路径
start_doy = 1
end_doy = 365

# 循环处理每一年
for doy in range(start_doy, end_doy + 1):
    # 构建输入和输出文件名
    input_filename = f'mean_2m_air_temperature_{doy}.tif'
    output_filename = f'{doy}.envi'

    # 构建输入和输出文件路径
    input_filepath = os.path.join(folder_path, input_filename)
    output_filepath = os.path.join(folder_path, output_filename)

    # 构建GDAL命令
    gdal_command = [
        'gdal_translate',
        '-of', 'ENVI',
        '-co', 'INTERLEAVE=BSQ',
        input_filepath,
        output_filepath
    ]

    # 运行GDAL命令
    subprocess.run(gdal_command)

    print(f'转换完成：{input_filepath} 到 {output_filepath}')
