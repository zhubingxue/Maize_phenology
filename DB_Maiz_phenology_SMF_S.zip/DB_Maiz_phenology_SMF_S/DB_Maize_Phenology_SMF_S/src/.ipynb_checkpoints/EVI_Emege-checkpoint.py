from osgeo import gdal

# 输入文件列表
input_files = ['SMF_S_Release-main/data/Modis/modis_evi_2021_01_09.tif', 'SMF_S_Release-main/data/Modis/modis_evi_2021_01_25.tif',
               'SMF_S_Release-main/data/Modis/modis_evi_2021_02_10.tif', 'SMF_S_Release-main/data/Modis/modis_evi_2021_02_26.tif',
               'SMF_S_Release-main/data/Modis/modis_evi_2021_03_14.tif', 'SMF_S_Release-main/data/Modis/modis_evi_2021_03_30.tif',
               'SMF_S_Release-main/data/Modis/modis_evi_2021_04_15.tif', 'SMF_S_Release-main/data/Modis/modis_evi_2021_05_01.tif',
               'SMF_S_Release-main/data/Modis/modis_evi_2021_05_17.tif', 'SMF_S_Release-main/data/Modis/modis_evi_2021_06_02.tif',
               'SMF_S_Release-main/data/Modis/modis_evi_2021_06_18.tif', 'SMF_S_Release-main/data/Modis/modis_evi_2021_07_04.tif',
               'SMF_S_Release-main/data/Modis/modis_evi_2021_07_20.tif', 'SMF_S_Release-main/data/Modis/modis_evi_2021_08_05.tif',
               'SMF_S_Release-main/data/Modis/modis_evi_2021_08_21.tif', 'SMF_S_Release-main/data/Modis/modis_evi_2021_09_06.tif',
               'SMF_S_Release-main/data/Modis/modis_evi_2021_09_22.tif', 'SMF_S_Release-main/data/Modis/modis_evi_2021_10_08.tif',
               'SMF_S_Release-main/data/Modis/modis_evi_2021_10_24.tif', 'SMF_S_Release-main/data/Modis/modis_evi_2021_11_09.tif',
               'SMF_S_Release-main/data/Modis/modis_evi_2021_11_25.tif', 'SMF_S_Release-main/data/Modis/modis_evi_2021_12_11.tif',
               'SMF_S_Release-main/data/Modis/modis_evi_2021_12_27.tif']

# 输出合并后的文件
output_file = 'merged_output.tif'

# 打开第一个文件，获取相关信息
first_dataset = gdal.Open(input_files[0])
driver = gdal.GetDriverByName("GTiff")

# 创建输出文件
output_dataset = driver.CreateCopy(output_file, first_dataset)

# 将其他文件追加到输出文件中
for file in input_files[1:]:
    dataset = gdal.Open(file)
    output_dataset.WriteRaster(0, 0, dataset.RasterXSize, dataset.RasterYSize, dataset.ReadRaster())
    dataset = None

# 关闭数据集
output_dataset = None
first_dataset = None

print("Merge completed.")
