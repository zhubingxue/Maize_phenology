from osgeo import gdal
from random import randint
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
import numpy as np
import os
import sys
sys.path.append("..")
from chensg import chen_sg_filter as cf
from tqdm import tqdm
# 使用gdal库导入测试EVI（增强植被指数）图像，该图像地区位于华北平原，主要作物为小麦，图像时间分辨率：500米，空间分辨率：8天（2007-8-1到2008-8-1）
os.chdir(r"C:\Users\Administrator\Desktop\SMF_S_Release-main\SMF_S_Release-main\data")
dts = gdal.Open("winter_wheat_cover")
# proj：投影信息  geto：地理信息。包括六个参数：左上角x坐标、水平像素分辨率、旋转参数（通常为0，表示图像未旋转）、左上角y坐标、垂直像素分辨率、旋转参数（通常为0）
proj, geot = dts.GetProjection(), dts.GetGeoTransform()
# 将获取图片栅格数据以NumPy数组的形式存储，方便进行后续操作
img_cover = dts.ReadAsArray()
# 对数据进行缩放
img_evi_ts = gdal.Open("EVI_2008").ReadAsArray() * 1e-4

# print(img_cover.shape)
# print(img_evi_ts.shape)

def random_a_point():
    while True:
        x, y = randint(0, 399), randint(0, 399)
        if img_cover[x, y] == 1:
            return x, y


# 使用matplotlib绘制四个子图，包括冬小麦图，平均EVI，随机两个像素的EVI时间序列
ticks_font = FontProperties(fname="C:\\Windows\\Fonts\\arial.ttf", size=14)

DOYs = np.arange(1, 366, 8)

plt.figure(figsize=(9, 9))

plt.subplot(221)
plt.title("Winter Wheat Mapping")
plt.imshow(img_cover, vmin=0.1, vmax=0.6)
plt.xticks([], []); plt.yticks([], [])


plt.subplot(222)
plt.title("Mean EVI")
plt.imshow(np.mean(img_evi_ts, axis=0), cmap="jet")
plt.xticks([], []); plt.yticks([], [])
plt.colorbar()

time_labels_4 = ["Sep", "Dec", "Mar", "Jun"]
time_xlength_4 = np.arange(45, 365, 90)

plt.subplot(223)
plt.title("Random Selected EVI curve")
p = random_a_point()
plt.plot(DOYs, img_evi_ts[:, p[0], p[1]], lw=3, c='k')
plt.xticks(time_xlength_4, time_labels_4, fontproperties=ticks_font)
plt.yticks(fontproperties=ticks_font)
plt.xlabel("Month", fontproperties=ticks_font)
plt.ylabel("EVI", fontproperties=ticks_font)

plt.subplot(224)
plt.title("Random Selected EVI curve")
p = random_a_point()
plt.plot(DOYs, img_evi_ts[:, p[0], p[1]], lw=3, c='k')
plt.xticks(time_xlength_4, time_labels_4, fontproperties=ticks_font)
plt.yticks(fontproperties=ticks_font)
plt.xlabel("Month", fontproperties=ticks_font)
plt.ylabel("EVI", fontproperties=ticks_font)
# plt.show()


# 导入参考EVI和参考物候
path_ref_evi = open('ref_evi.txt')
evi_ts_ref = []
for line in path_ref_evi.readlines():
    evi_ts_ref.append(float(line))
evi_ts_ref = np.array(evi_ts_ref)

path_ref_phe = open('ref_phe.txt')
phe_ref = []
for line in path_ref_phe.readlines():
    phe_ref.append(float(line))
phe_ref = np.array(phe_ref)

plt.figure(figsize=(5, 4))
plt.plot(DOYs, evi_ts_ref, lw=3, c='k')
plt.xticks(time_xlength_4, time_labels_4, fontproperties=ticks_font)
plt.yticks(fontproperties=ticks_font)
plt.xlabel("Month", fontproperties=ticks_font)
plt.ylabel("EVI", fontproperties=ticks_font)
for i in range(9):
    plt.scatter(phe_ref[i], np.interp(phe_ref[i], DOYs, evi_ts_ref), c="C{}".format(i), zorder=10, edgecolor='k', s=70)
# plt.show()

# 使用SG滤波器来过滤EVI植被曲线
img_evi_fts = np.copy(img_evi_ts)
xlen, ylen = img_cover.shape
for i in tqdm(range(xlen)):
    for j in range(ylen):
        img_evi_fts[:, i, j] = cf(img_evi_ts[:, i, j])

# 绘制过滤后的时间曲线
plt.figure(figsize=(9, 4))

plt.subplot(121)
p = random_a_point()
plt.plot(DOYs, img_evi_ts[:, p[0], p[1]], lw=3, c="r", ls='--')
plt.plot(DOYs, img_evi_fts[:, p[0], p[1]], lw=3, c="k", ls='-')

plt.xticks(time_xlength_4, time_labels_4, fontproperties=ticks_font)
plt.yticks(fontproperties=ticks_font)
plt.xlabel("Month", fontproperties=ticks_font)
plt.ylabel("EVI", fontproperties=ticks_font)

plt.subplot(122)
p = random_a_point()
plt.plot(DOYs, img_evi_ts[:, p[0], p[1]], lw=3, c="r", ls='--')
plt.plot(DOYs, img_evi_fts[:, p[0], p[1]], lw=3, c="k", ls='-')
plt.xticks(time_xlength_4, time_labels_4, fontproperties=ticks_font)
plt.yticks(fontproperties=ticks_font)
plt.xlabel("Month", fontproperties=ticks_font)
plt.ylabel("EVI", fontproperties=ticks_font)
# plt.show()


# 删除冬小麦生长季节两端
from scipy.signal import argrelextrema
BREAK_POINTS = (90, 300)
def flatten(curve, doy=DOYs):
    # 找到曲线中的局部最小值
    minimal_locs = np.array(argrelextrema(curve, np.less_equal)).reshape(-1)
    # 将拐点位置从日期（DOY）转换为曲线上的索引位置
    locs = np.interp(BREAK_POINTS, doy, np.arange(46))
    # 获得最接近拐点位置的局部最小值的索引
    first_mini = minimal_locs[np.argmin(np.abs(minimal_locs - locs[0]))]
    second_mini = minimal_locs[np.argmin(np.abs(minimal_locs - locs[1]))]
    # 使用副本避免影响原数组
    curve = np.copy(curve)
    # 将第一个拐点之前的值设置为第一个拐点的值
    curve[:first_mini] = curve[first_mini]
    # 将第二个拐点之后的值设为第二个拐点的值
    curve[second_mini:] = curve[second_mini]
    # 相当于删除生长季节两端的值
    return curve

img_evi_ffts = np.copy(img_evi_fts)
for i in range(xlen):
    for j in range(ylen):
        if img_cover[i, j]:
            img_evi_ffts[:, i, j] = flatten(img_evi_fts[:, i, j])

evi_fts_ref = flatten(evi_ts_ref)

plt.figure(figsize=(9, 4))

plt.subplot(121)
p = random_a_point()
plt.plot(DOYs, img_evi_ts[:, p[0], p[1]], lw=3, c="r", ls="--")
plt.plot(DOYs, img_evi_fts[:, p[0], p[1]], lw=3, c="k", ls="--")
plt.plot(DOYs, img_evi_ffts[:, p[0], p[1]], lw=3, c="k", ls="-")
plt.xticks(time_xlength_4, time_labels_4, fontproperties=ticks_font)
plt.yticks(fontproperties=ticks_font)
plt.xlabel("Month", fontproperties=ticks_font)
plt.ylabel("EVI", fontproperties=ticks_font)

plt.subplot(122)
p = random_a_point()
plt.plot(DOYs, img_evi_ts[:, p[0], p[1]], lw=3, c="r", ls="--")
plt.plot(DOYs, img_evi_fts[:, p[0], p[1]], lw=3, c="k", ls="--")
plt.plot(DOYs, img_evi_ffts[:, p[0], p[1]], lw=3, c="k", ls="-")
plt.xticks(time_xlength_4, time_labels_4, fontproperties=ticks_font)
plt.yticks(fontproperties=ticks_font)
plt.xlabel("Month", fontproperties=ticks_font)
plt.ylabel("EVI", fontproperties=ticks_font)

plt.show()

# 调用SMF-S方法识别物候期
from smf_s_class_zs import SMFS
img_smfsphes = np.zeros((len(phe_ref), xlen, ylen))
for phe_i in (1, 4, 8): # Detect EMG, GUD and MAT
    smfs_model = SMFS(evi_fts_ref, phe_ref[phe_i], DOYs)
    for i in tqdm(range(xlen)):
        for j in range(ylen):
            if not img_cover[i, j]:
                continue
            img_smfsphes[phe_i, i, j] = smfs_model.doit(img_evi_ffts[:, i, j])

# 随机选点观察物候期
plt.figure(figsize=(16, 4))
for i_map in range(3):
    plt.subplot(1, 3, i_map + 1)
    p = random_a_point()
    p[0], p[1]

    plt.plot(DOYs, img_evi_ts[:, p[0], p[1]], lw=3, c="r", ls="--")
    plt.plot(DOYs, img_evi_fts[:, p[0], p[1]], lw=3, c="k", ls="--")
    plt.plot(DOYs, img_evi_ffts[:, p[0], p[1]], lw=3, c="k", ls="-")
    phe_detected = img_smfsphes[:, p[0], p[1]]
    for i in range(9):
        if phe_detected[i] == 0:
            continue
        plt.scatter(phe_detected[i],
                    np.interp(phe_detected[i], DOYs, img_evi_ffts[:, p[0], p[1]]),
                    c='C{}'.format(i),
                    s=70,
                    zorder=10,
                    edgecolor='k')
    plt.xticks(time_xlength_4, time_labels_4, fontproperties=ticks_font)
    plt.yticks(fontproperties=ticks_font)
    plt.xlabel("Month", fontproperties=ticks_font)
    plt.ylabel("EVI", fontproperties=ticks_font)
plt.show()

plt.figure(figsize=(16, 4))
plt.subplot(131)
plt.title("EMG")
plt.imshow(img_smfsphes[1, :, :], vmin=70, vmax=100, cmap="jet")
plt.xticks([], []); plt.yticks([], [])
plt.colorbar()

plt.subplot(132)
plt.title("GUD")
plt.imshow(img_smfsphes[4, :, :], vmin=190, vmax=220, cmap="jet")
plt.xticks([], []); plt.yticks([], [])
plt.colorbar()

plt.subplot(133)
plt.title("MAT")
plt.imshow(img_smfsphes[8, :, :], vmin=290, vmax=320, cmap="jet")
plt.xticks([], []); plt.yticks([], [])
plt.colorbar()
plt.show()


