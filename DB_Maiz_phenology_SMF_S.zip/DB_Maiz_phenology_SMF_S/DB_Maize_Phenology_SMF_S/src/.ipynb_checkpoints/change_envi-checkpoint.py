import os

folder_path = "E:\\Google下载\\JL"
for filename in os.listdir(folder_path):
    if filename.endswith(".envi"):
        new_filename = os.path.join(folder_path, os.path.splitext(filename)[0])
        os.rename(os.path.join(folder_path, filename), new_filename)
