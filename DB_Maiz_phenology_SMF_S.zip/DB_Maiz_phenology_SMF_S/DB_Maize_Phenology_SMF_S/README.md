# SMF_S_Release
Detecting crop phenology from vegetation index time-series data by improved shape model fitting in each phenological stage.
